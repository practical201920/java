import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class NumberP implements Runnable
{
	Number num;
	Component  comp;
	
	NumberP(Number n,Component c)
	{
		num=n;
		comp=c;
	}
	public void run()
	{
		while(true)
		{
			num.move(comp);
			comp.repaint();
			try
			{
				Thread.sleep(100);
			}catch(InterruptedException e){}	
		}
	}
}
class Number
{
	int x,y,dy=1;
	String no;
	Color c;
	Number()
	{
		x=(int)(Math.random()*500);
		y=(int)(Math.random()*500);
		no=Integer.toString((int)(Math.random()*10+1));
		c=new Color((int)(Math.random()*200),(int)(Math.random()*200),(int)(Math.random()*200));
	}
	public int getx()
	{
		return x;
	}
	public int gety()
	{
		return y;
	}
	public String getNumber()
	{
		return no;
	}
	public Color getColor()
	{
		return c;
	}
	public void move(Component bound)
	{
		y +=dy;
		if(y<0)	
		{
		y=0;
		dy=-dy;
		}
	 	if(y>=bound.getHeight())
		{
			y=bound.getHeight();
			dy=-dy;
		}
	}
}
class npanel extends JPanel
{
	ArrayList<Number> num=new ArrayList<Number>();

	public void add(Number b)
	{
		num.add(b);
	}
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		for(Number b : num)
		{
			g.setColor(b.getColor());
			g.drawString(b.getNumber(),b.getx(),b.gety());
		}
	}
}
class Bframe extends JFrame
{
	npanel p;
	JPanel bpanel;
	JButton start,close;
	
	Bframe()
	{
		setSize(500,500);
		setTitle("BounceThread");
		
		p=new npanel();
		
		bpanel=new JPanel();
		start=new JButton("Start");
		close=new JButton("close");
		bpanel.add(start);
		bpanel.add(close);
		add(p,BorderLayout.CENTER);
		add(bpanel,BorderLayout.SOUTH);
		start.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e){
				addb();}
			});
		close.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e){
			System.exit(0);
			}});
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}

	public void addb()
	{
		Number b=new Number();
		p.add(b);
		Runnable r=new NumberP(b,p);
		Thread t=new Thread(r);
		t.start();
	}
}

public class slip5_2
{
	public static void main(String args[])
	{
		new Bframe();
	}
}
			
			
		
