import java.util.*;
class InsufficientFundException extends Exception
{
}
class account
{
  int ano;
   String name;
   double bal;
 account(int ano,String name,double bal)
 {
   this.ano=ano;
   this.name=name;
   this.bal=bal;
 }
 void diposite()
 {
   double amt;
  Scanner s=new Scanner(System.in);
  System.out.println("Enter the amount to be diposite:");
  amt=s.nextInt();
  bal=bal+amt;
 }
 void viewbal()
 {
  System.out.println("Avialable balence is:"+bal);
 }
  void withdrawl()
  {
   double amt;
    Scanner s=new Scanner(System.in);
  try
  {
   System.out.println("Enter the amount to withdraw .");
   amt=s.nextDouble();
   bal=bal-amt;
   if(bal<500)
   throw new InsufficientFundException();
   else
  bal=bal-amt;
 }
 catch(InsufficientFundException e)
 {
  System.out.println("minimum balance ");
} 
 }
   public static void main(String args[])
  {
      account a=new account(1,"Test",600);
      a.diposite();
      a.viewbal();
      a.withdrawl();
  }
  }
 
   
