import java.io.*;
class e34
{
	public static void main(String a[])throws IOException
	{
		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
		if(a.length==1)
		{
			File f1=new File(a[0]);
			if(f1.isDirectory())
			{
				String s[]=f1.list();
				int count=0;
				for(int i=0;i<s.length;i++)
				{
					File f=new File(a[0]+"/"+s[i]);
					if(f.isDirectory())
						System.out.println(s[i]+" is a Directory");
					else
					{
						count++;
						if(s[i].endsWith(".txt"))
						{
							System.out.println("Delete File "+s[i]+" ? (yes/no)");
							String choice=bf.readLine();
							if(choice.compareTo("yes")==0)
								f.delete();
							else
								System.out.println(s[i]+" is a File");
						}
						else
							System.out.println(s[i]+"is a File");
					}
				}
				System.out.println("The Directory has "+count+" Files");
			}
			else
			{
				System.out.println("Absolute path of File is :"+f1.getAbsolutePath());
				System.out.println("Size of File is :"+f1.length());
				if(f1.canRead())
					System.out.println("File is Readable");
				else if(f1.canWrite())
					System.out.println("File is Writeable");
				else
					System.out.println("File is Hidden");
			}
		}
		else
			System.out.println("Enter the File name or Directory name in command line");
	}
}
