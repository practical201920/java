class mythread extends Thread
  {

  	String msg;
  	int n,i;
  	share s;
  	mythread(share s,String msg,int n)
  	 {
  	   super(msg);
  	   this.s=s;
  	   
  	   this.msg=msg;
  	   this.n=n;
  	   start();
  	 } 
  	public void run()
  	 {
  	    s.doword(msg,n);        
     }
  }
class share
  {
  	public synchronized  void doword(String msg,int n)
  	  {
  	  	for(int i=0;i<n;i++)
  	  	  System.out.println(msg);
  	  }
  }	  	   
class slip11_2
  {
  	public static void main(String args[])
  	  {
  	  	share s=new share();
  	  	mythread m1=new mythread(s,"I am in FY",10);
  	    mythread m2=new mythread(s,"I am in SY",20);
  	  	mythread m3=new mythread(s,"I am in TY",30);
  	  }
  }
