import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class slip4_1 extends HttpServlet
{	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException,ServletException
	{
		doPost(req,res);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException,ServletException
	{
		PrintWriter out=res.getWriter();
		java.util.Properties p=System.getProperties();
		out.println("Server Name:"+req.getServerName());
		out.println("Server Port:"+req.getServerPort());
		out.println("Local address:"+req.getLocalAddr());
		out.println("Servlet Name:"+this.getServletName());
		out.println("OS Name:"+p.getProperty("os.name"));
	}
}
