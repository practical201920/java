import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
class myframe extends JFrame implements ActionListener
  {
	JTextArea ta;
    JMenuBar mb;
    JMenu file,sort;
    JMenuItem load,save,exit,asc,desc;
    int i=0,j,cnt=0,s=0,mx=0,mn=1000000;   
    int data[]=new int[10];
    String fname,sname; 
   myframe() //throws EOFException
     {
       mb=new JMenuBar();
       file=new JMenu("File");
       sort=new JMenu("Sort");
       asc=new JMenuItem("Ascending");
	desc=new JMenuItem("Descending");
       load=new JMenuItem("Load");
       save=new JMenuItem("Save");
       exit=new JMenuItem("Exit");
       ta=new JTextArea(4,50);
       setLayout(new BorderLayout());
	add(ta);
       add(mb);
       mb.add(file);
       mb.add(sort);
       file.add(load);
       file.add(save);
       file.addSeparator();
       file.add(exit);
      sort.add(asc);
      sort.add(desc);
      load.addActionListener(this);
       save.addActionListener(this);
       exit.addActionListener(this);
       asc.addActionListener(this);
       desc.addActionListener(this);
	ta.setBounds(50,100,300,40);
       setJMenuBar(mb);
       setSize(500,250);
       setVisible(true);
    }
   public void actionPerformed(ActionEvent a) 
    {
      i=cnt=s=mx=0;
      mn=1000000;  
      JLabel[] l = new JLabel[20];
    	try
    	 {
    	  if(a.getSource()==load) 
    	   {
		ta.setText("Numbers : ");
		for (int i = 0; i < 10; i++)
		{
			Random generator = new Random();
			data[i] = generator.nextInt(100);
			String d=" "+data[i];
			ta.append(d);
		}
    	   }
    	  if(a.getSource()==save) 
    	   { 
		FileWriter dos=new FileWriter(new File("numbers.txt"));
    	      for(i=0;i<10;i++)
    	       {
		dos.write(" "+data[i]);
    	       }	
		dos.close();
    	   }
           if(a.getSource()==asc) 
    	     { 

               for(i=1;i<10;i++)
                {
               	  for(j=0;j<9;j++)
		{
               	    if(data[j]>data[j+1] )
               	      {
               	      	 int s=data[j+1];
               	      	 data[j+1]=data[j];
               	      	 data[j]=s;
               	      }	                 
		}
               	}
		ta.setText("Numbers : ");
		for(i=0;i<10;i++)
		{
			String d=" "+data[i];
			ta.append(d);

		}
             } 
           if(a.getSource()==desc) 
    	     { 

               for(i=1;i<10;i++)
                {
               	  for(j=0;j<9;j++)
		{
               	    if(data[j]<data[j+1] )
               	      {
               	      	 int s=data[j+1];
               	      	 data[j+1]=data[j];
               	      	 data[j]=s;
               	      }	                 
		}
               	}
		ta.setText("Numbers : ");
		for(i=0;i<10;i++)
		{
			String d=" "+data[i];
			ta.append(d);

		}             }  
           if(a.getSource()==exit) 
    	     { 
    	       System.exit(0);
             }          
          }    
       	catch(Exception e)
    	 {
    	 	System.out.println("Error:"+e);
    	 }  
    } 
}
class slip4_1
 {
   public static void main(String args[]) throws EOFException
     {
       new myframe();
     }
 }
