import java.net.*;
import java.io.*;
public class ServerFile
{
  public static void main(String args[]) throws UnknownHostException,IOException
  {
    ServerSocket ss=new ServerSocket(5678);
    System.out.println("Server started,waiting for file name.");
    Socket s=ss.accept();
    System.out.println("Client connected");
    InputStream i=s.getInputStream();
    DataInputStream ds=new DataInputStream(i);
    String fn=ds.readUTF();
    OutputStream o=s.getOutputStream();
    DataOutputStream ds1=new DataOutputStream(o);
    File f1=new File(fn);
    String msg=" ";
    int c;
    if(f1.exists())
    {
      System.out.println("File exists");
      FileInputStream fs=new FileInputStream(f1);
      while((c=fs.read())!=-1)
      {
	msg=msg+(char)c;
      }	
      ds1.writeUTF(msg);	
      fs.close();
    }
    else
    {
      ds1.writeUTF("0");
    }
    ds.close();
    ds1.close();
    s.close();
   }
}                                       

