import java.net.*;
import java.io.*;
class ClientFile
{
	public static void main(String args[]) throws UnknownHostException,IOException
	{
		Socket s=new Socket("localhost",5678);
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter file name to search");
		String fn=br.readLine();
		OutputStream o=s.getOutputStream();
		DataOutputStream ds1=new DataOutputStream(o);
		ds1.writeUTF(fn);
		InputStream i=s.getInputStream();
		DataInputStream dis=new DataInputStream(i);
		String msg=dis.readUTF();
		if(!msg.equals("0"))
		{
			System.out.println("File contents are:");
			System.out.println(msg);
		}
		else
			System.out.println("File not present");
		br.close();
		ds1.close();
		dis.close();
		s.close();
	}
}	

