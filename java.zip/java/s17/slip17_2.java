import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
public class Slip17_2 extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws
	IOException, ServletException
	{
		response.setContentType(“text/html”);
		PrintWriter out= res.getWriter();
		String name=req.getParmeter(“name”),msg;
		String password=req.getParmeter(“password”);
		Connection con=null;
		Statement st=null;
		ResultSet rs=null;
		out.println(“<HTML>”);
		out.println(“<BODY>”);
		try
		{
			Class.forName(“org.postgresql.Driver”);
			Class.forName(“org.postgresql.Driver”);
			con=DriverManager.getConnection(“jdbc:postgresql:localhost
			/serv”,”user”,”pass”);
			if(con==null)
			msg=”Connection to databse failed”;
			else
			{
			st=con.createStatement();
			rs=st.executeQuery(“select * from Login where name = ‘”+
			name+ “’ and password=’”+password+”’”);
			if(rs==null)
			out.println(“No such user);
			else
			out.println(“Welcome: ‘”+name+”’”);
			}
		}
		catch(Exception e) { }
		out.println(“</BODY>”);
		out.println(“</HTML>”);
	}
}
