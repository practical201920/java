import java.io.*;
abstract class Staff
{
	public String name,addr;
	public Staff(String nme,String adr)
	{
		name=nme;
		addr=adr;
	}
	abstract void display();
}
class FullTimeStaff extends Staff
{
	public String dept;
	public double sal;
	public FullTimeStaff(String nme,String adr,String dpt,double s)
	{
		super(nme,adr);
		dept=dpt;
		sal=s;
	}
	public void display()
	{
		System.out.println(name+"\t"+addr+"\t"+dept+"\t\t"+sal);
	}
}
class PartTimeStaff extends Staff
{
	public int no_of_hours;
	public double rate_per_hour;
	public PartTimeStaff(String nme,String adr,int no,double r)
	{
		super(nme,adr);
		no_of_hours=no;
		rate_per_hour=r;
	}
	public void display()
	{
		System.out.println(name+"\t"+addr+"\t\t"+no_of_hours+"\t\t"+rate_per_hour+"\t"+(no_of_hours*rate_per_hour));
	}
}
class slip17_1
{
	public static void main(String a[])throws IOException
	{
		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the total staff");
		int n=Integer.parseInt(bf.readLine());
		System.out.println("Enter the details of "+n+" Member of staff");
		FullTimeStaff[] f=new FullTimeStaff[n];
		PartTimeStaff[] p=new PartTimeStaff[n];
		int m=0,r=0,ch;
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter 1 for Full time staff and 2 for Part time staff");
			ch=Integer.parseInt(bf.readLine());
			if(ch==1)
			{
				System.out.println("Enter the name, address, department, salary");
				f[m]=new FullTimeStaff(bf.readLine(),bf.readLine(),bf.readLine(),Double.parseDouble(bf.readLine()));
				m++;
			}
			else
			{
				System.out.println("Enter the name, address, no of hours work, Rate per hours");
				p[r]=new PartTimeStaff(bf.readLine(),bf.readLine(),Integer.parseInt(bf.readLine()),Double.parseDouble(bf.readLine()));
				r++;
			}
		}
		System.out.println("------Full Time Staff details------");
		System.out.println("Name\tAddress\tDepartment\tSalary");
		for(int i=0;i<m;i++)
		{
			f[i].display();
		}
		System.out.println("\n------Part Time Staff Details------");
		System.out.println("Name\tAddress\tTotal hours\tRate Per hour\t Salary");
		for(int i=0;i<r;i++)
		{
			p[i].display();
		}
	}
}
