import java.io.*;
class file7
 {
  public static void main(String args[]) throws IOException
   {
     int id[]=new int[10];
     int price[]=new int[10];
     int qty[]=new int[10];
     String name[]=new String[10];
     int ch,i=0,cnt=0,flag=0;
     BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
     try
     {
       FileInputStream fis=new FileInputStream("item.dat");
       DataInputStream dis=new DataInputStream(fis);
       while(fis.available() > 0)
        {	
         String line=dis.readLine();
         String s[]=line.split(" ");
         id[i]=Integer.parseInt(s[0]);
         name[i]=s[1];
         price[i]=Integer.parseInt(s[2]);
         qty[i]=Integer.parseInt(s[3]);
         cnt++;    
         i++;
        }  
       System.out.println("Main menu for Item");
       System.out.println("1: Search for specific Item by name.");
       System.out.println("2: Find costliest item.");
       System.out.println("3: Display all items and total cost.");
       System.out.println("Enter your choice: ");
       ch=Integer.parseInt(br.readLine());
       switch(ch)
        {
         case 1: System.out.println("Enter the Item name: ");
                 String iname=br.readLine();
                 for(i=0;i<cnt;i++)
                    if(name[i].equalsIgnoreCase(iname))
                      {
                        System.out.println("Item id\tItem name\tItem price\tItem qty");
                        System.out.println(id[i]+"\t"+name[i]+"\t"+price[i]+"\t"+qty[i]);
                        flag=1;
                        break;
                      } 
                 if(flag==0)
                   System.out.println("The item name does not found in a file.");  
                 break;  
         case 2: int max=0;
                 for(i=0;i<cnt;i++)
                  {
                    if(price[i] > max)
                     {
                      max=price[i];
                      flag=i;
                     }
                  }
                System.out.println("The costliest item is:");
                System.out.println("Item id Item name Item price Item qty");
                System.out.println(id[flag]+"\t"+name[flag]+"\t"+price[flag]+"\t"+qty[flag]);
                break;

          case 3:System.out.println("The items are: ");
                System.out.println("Item id\tItem name Item price Item qty\tTotal cost");
                for(i=0;i<cnt;i++)
                   System.out.println(id[i]+"\t"+name[i]+"\t"+price[i]+"\t"+qty[i]+"\t"+price[i]*qty[i]);
                break;
         }
        }
      catch(NumberFormatException e)
       {
         System.out.println("Enter only Integer values ");
       }
    }
  }
        

