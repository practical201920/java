import java.io.*;
import java.util.*;
class slip15_2
{
	public static void main(String args[])throws IOException
	{
		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
		Hashtable ht=new Hashtable();
		Enumeration names;
		String str;
		double perc;
		ht.put("Pratik",new Double(92.80));
		ht.put("Kajal",new Double(92.81));
		ht.put("Rohit",new Double(92.82));
		ht.put("kaveri",new Double(92.83));
		names=ht.keys();
		while(names.hasMoreElements())
		{
			str=(String)names.nextElement();
			System.out.println(str+" : "+ht.get(str));
		}
		System.out.println("Enter Student Name:");
		String name=bf.readLine();
		System.out.println("Percentage of "+name+":"+ht.get(names));
	}
}
