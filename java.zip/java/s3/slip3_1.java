
import java.io.*;
import java.util.*;
class mydate
 {
   int day,mon,yr;

   mydate()
    {
      day=mon=yr=0;
    }

   mydate(int d,int m,int y)
    {
      day=d;
      mon=m;
      yr=y;
      try
       {
         if(day<=0 || day>=32)
           throw new InvalidDayException();
         else
         if(mon<=0 || mon>=13)
           throw new InvalidMonthException();
         else
           throw new ValidDate();

       }
     catch(InvalidDayException e)
       {
         System.out.println("The day should be less than 32 and greater than 0 ");
       }
     catch(InvalidMonthException e)
       {
         System.out.println("The month should be less than 13 and greater than 0");
       }
     catch(ValidDate e)
       {
         System.out.println("The date is valid");
       }
    }

  public static void main(String args[])
    {
      int a[]=new int[3];
      for(int i=0;i<3;i++)
       a[i]=Integer.parseInt(args[i]);
      mydate m=new mydate(a[0],a[1],a[2]);
    }
 }

class InvalidDayException extends Exception { }
class InvalidMonthException extends Exception { };
class ValidDate extends Exception { };

