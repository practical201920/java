import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class setA3 extends HttpServlet
{
	ResultSet rs;
	Statement st;
	Connection c=null;
	int billno;
	public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException, IOException
	{
		try
		{
			Class.forName("org.postgresql.Driver");
			c=DriverManager.getConnection("jdbc:postgresql://localhost:5432/java","temp","butterfly@123");
		}
		catch(Exception e)
		{
			System.out.println("Error:"+e);
		}
		billno=Integer.parseInt(req.getParameter("billno"));
		res.setContentType("html/css");
		PrintWriter pw=res.getWriter();
		try
		{

			st=c.createStatement();
			rs=st.executeQuery(" select * from BillMaster,BillDetails where BillMaster.billno=BillDetails.billno and BillMaster.billno='"+billno+"';");
			boolean flag=true;
			while(rs.next())
			{
				String cname=rs.getInt(1));
				pw.print("Student Percentage:"+rs.getDouble(3));
				flag=false;
			}
			if(flag)
			{
				pw.print("Invalid Roll No.");
			}
			st=c.createStatement();
			rs=st.executeQuery(" select * from BillMaster,BillDetails where BillMaster.billno=BillDetails.billno and BillMaster.billno='"+roll+"';");
			boolean flag=true;
			while(rs.next())
			{
				pw.print("Student Name:"+rs.getInt(1));
				pw.print("Student Percentage:"+rs.getDouble(3));
				flag=false;
			}
			if(flag)
			{
				pw.print("Invalid Roll No.");
			}
			
		}
		catch(Exception e)
		{
			System.out.println("Error:"+e);
		}				
	}
}
