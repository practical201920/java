import java.io.*;
class Employee implements Cloneable
{
	public int id;
	public String name,date;
	public Employee(int i,String nme,String dte)
	{
		id=i;
		name=nme;
		date=dte;
	}

}
class Manager extends Employee implements Cloneable
{
	public String dept,jdate;
	public Manager(int i,String nme,String dte,String dpt,String jdte)
	{
		super(i,nme,dte);
		dept=dpt;
		jdate=jdte;
	}

	public void display()
        {
                System.out.println(id+"\t"+name+"\t"+date+"\t"+dept+"\t"+jdate);
        }
}
class slip25_1
{
	public static void main(String a[]) throws IOException
	{
		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the total manager");
		int n=Integer.parseInt(bf.readLine());
		Manager[] m=new Manager[n];
	
		System.out.println("Enter the details of "+n+" Manager");
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter id, name, date of birth, department, joining date");
			m[i]=new Manager(Integer.parseInt(bf.readLine()),bf.readLine(),bf.readLine(),bf.readLine(),bf.readLine());
		}

		System.out.println("------Manager Details------");
		System.out.println("id\tName\tBirth Date\tDepartment\tJoining Date");
		for(int i=0;i<n;i++)
		{
			m[i].display();
		}
	}
}
