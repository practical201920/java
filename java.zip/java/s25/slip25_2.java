import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class setB1p2 extends HttpServlet
{
	public void doPost(HttpServletRequest req,HttpServletResponse res)throws IOException,ServletException
	{
		PrintWriter out=res.getWriter();
		String iname2=req.getParameter("iname2");
		double i2p=Double.parseDouble(req.getParameter("prize2"));
		int i2q=Integer.parseInt(req.getParameter("qty2"));
		HttpSession session=req.getSession();
		double total=(double)session.getAttribute("total");
		double total1=total+(i2p*i2q);
		String cname=(String)session.getAttribute("cname");
		String iname1=(String)session.getAttribute("iname1");
		double i1p=(double)session.getAttribute("i1p");
		int i1q=(int)session.getAttribute("i1q");
		res.setContentType("text/html");
		out.print("<html><head><title>Bill</title></head><body><table align=\"center\"><th colspan=2>Customer Bill</th></table><table align=\"center\" border=\"double\"><th colspan=5>Customer Name :"+cname+"</th><tr><th>Item No</th><th>Item Name</th><th>Item Quantity</th><th>Item Prize</th><th>total</th></tr><tr><td>1</td><td>"+iname1+"</td><td>"+i1q+"</td><td>"+i1p+"</td><td>"+total+"</td></tr><tr><td>2</td><td>"+iname2+"</td><td>"+i2q+"</td><td>"+i2p+"</td><td>"+(i2p*i2q)+"</td></tr><tr><td></td><td></td><td></td><td>Total</td><td>"+total1+"</td></tr></table>");
	}
}
