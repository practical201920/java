import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
class slip12_1
{
	JFrame fr;
	JLabel l1,l2,l3;
	JTextField t1,t2;
	JCheckBox cx1,cx2,cx3;
	JRadioButton rb1,rb2,rb3;
	JPanel pn1,pn2,pn3,pn4,panel;
	String title;
	ButtonGroup btg;
	ActionListener listener;
	public static void main(String args[])
	{
		slip12_1 a2=new slip12_1 ();
		
	}
	public slip12_1()
	{
		fr=new JFrame(title);
		fr.setLayout(null);
		l1=new JLabel("Your Name :");
		l2=new JLabel("Your Class");
		l3=new JLabel("Your Hobbies");
		t1=new JTextField(20);
		t2=new JTextField(40);
		cx1=new JCheckBox("Music");
		cx2=new JCheckBox("Dance");
		cx3=new JCheckBox("Sports");
		btg=new ButtonGroup();
		rb1=new JRadioButton("FY");
		rb2=new JRadioButton("SY");
		rb3=new JRadioButton("TY");
		btg.add(rb1);
		btg.add(rb2);
		btg.add(rb3);
		pn1=new JPanel();
		pn1.setLayout(new GridLayout(4,1));
		pn1.add(l2);
		pn1.add(rb1);
		pn1.add(rb2);
		pn1.add(rb3);
		pn2=new JPanel();
		pn2.setLayout(new GridLayout(4,1));
		pn2.add(l3);
		pn2.add(cx1);
		pn2.add(cx2);
		pn2.add(cx3);
		pn3=new JPanel();
		pn3.setLayout(new FlowLayout());
		pn3.add(l1);
		pn3.add(t1);
		pn4=new JPanel();
		pn4.add(t2);
		panel=new JPanel();
		panel.setLayout(new BorderLayout());
		panel.add(pn3,BorderLayout.NORTH);
		panel.add(pn1,BorderLayout.WEST);
		panel.add(pn2,BorderLayout.EAST);
		panel.add(pn4,BorderLayout.SOUTH);
		panel.setBounds(10,10,480,210);
		fr.add(panel);
		//fr.setSize(500,230);
		fr.setSize(500,500);
		fr.setVisible(true);
		fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		listener=new MyAction();
		cx1.addActionListener(listener);
		cx2.addActionListener(listener);
		cx3.addActionListener(listener);
		t1.addActionListener(listener);
		rb1.addActionListener(listener);
		rb2.addActionListener(listener);
		rb3.addActionListener(listener);
	}
	public class MyAction implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			String str="Name: ";
			str+=t1.getText();
			str+=", Class: ";
			if(rb1.isSelected())
				str+="FY";
			else if(rb2.isSelected())
				str+="SY";
			else if(rb3.isSelected())
				str+="TY";
			else
				str+=" ";
			str+=", Hobbies:";
			if(cx1.isSelected())
				str+=" Music";
			if(cx2.isSelected())
				str+=" Dance";			
			if(cx3.isSelected())
				str+=" Sports";
			t2.setText(str);
		}
	}
}
