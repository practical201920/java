import java.util.Random;

class MyThread extends Thread
{
	public static int sum;
	Random r;
	MyThread(String name)
	{
		super(name);
		r=new Random();
	}
	public void run()
	{
		try
		{
			int s=0,i=0;
			while(i<100)
			{
				int a=r.nextInt();
				if(a>0&&a<32000)
				{
					s+=a;
					i++;
				}
				else
					continue;
			}
			System.out.println("Sum of 100 Integer in Thread "+getName()+": "+s);
			sum+=s;
		}
		catch(Exception e)
		{
			System.out.println("Error:"+e);
		}
	}
}
class slip12_2
{
	public static void main(String args[])
	{
		MyThread first=new MyThread("first");
		MyThread second=new MyThread("second");
		MyThread third=new MyThread("third");
		MyThread forth=new MyThread("forth");
		MyThread fifth=new MyThread("fifth");
		MyThread sixth=new MyThread("sixth");
		MyThread seventh=new MyThread("seventh");
		MyThread eighth=new MyThread("eighth");
		MyThread nineth=new MyThread("nineth");
		MyThread tenth=new MyThread("tenth");
		try
		{
			first.start();
			first.join();
			second.start();
			second.join();
			third.start();
			third.join();
			forth.start();
			forth.join();
			fifth.start();
			fifth.join();
			sixth.start();
			sixth.join();
			seventh.start();
			seventh.join();
			eighth.start();
			eighth.join();
			nineth.start();
			nineth.join();
			tenth.start();
			tenth.join();
			int x=first.sum;
			System.out.println("Total Thread Sum:"+x);
			System.out.println("Total Thread Average:"+(x/10));
			System.out.println("Total Integer Average:"+(x/1000));
		}
		catch(InterruptedException e)
		{
			System.out.println("Interrupted Error:"+e);
		}
	}
}
