package Series;
public class Square
{
        public void square_range(int no)
        {
                for(int i=1;i<=no;i++)
                {
                        System.out.println(i+" = "+(i*i));
                }
        }
}