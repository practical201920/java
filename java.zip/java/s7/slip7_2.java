import java.io.*;
import java.sql.*;
class slip7_2
{
	public static void main(String args[])
	{
		Connection con=null;
		Statement st1=null,st=null;
		ResultSet rs1=null,rs=null;
		PreparedStatement pst1=null,pst2=null,pst=null;
		int ch,eno,esal,flag=0;
		String name;
		int roll;
		double perc;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		try
		{
		        Class.forName("org.postgresql.Driver");
		        con=DriverManager.getConnection("jdbc:postgresql://localhost/dbname","user","pass");
		        System.out.println("Connection Created Successfully...");
		}
     		catch(Exception e)
      		{
        		System.out.println("Error in connection"+e);
      		}
     		try
     		{
     		do
          	{
         		System.out.println("1.Insert");
         		System.out.println("2.View All");
         		System.out.println("3.Modify");
         		System.out.println("4.Delete");
         		System.out.println("5.Search");
         		System.out.println("6.Exit");
         		System.out.print("Enter Your Choice: ");
         		ch=Integer.parseInt(br.readLine());
		        switch(ch)
    			{
                	   case 1:System.out.print("Enter Student roll No:");
                	          roll=Integer.parseInt(br.readLine());
                	          System.out.print("Enter Student Name:");
                	          name=br.readLine();
                	          System.out.print("Enter Student Percentage:");
                	          perc=Double.parseDouble(br.readLine());
                	          pst=con.prepareStatement("insert into student values(?,?,?)");
                	          pst.setInt(1,roll);
                	          pst.setString(2,name);
                	          pst.setDouble(3,perc);
                	          pst.executeUpdate();
                	          pst.close();
                	          System.out.println("Record Inserted Successfully...");
                	          break;
                	   case 2:st=con.createStatement();
                	          rs=st.executeQuery("select * from student");
                	          System.out.println("Roll No\tStudent Name\tPercentage");
                	          while(rs.next())
                	          {
                	            int no1=rs.getInt(1);
                	            String name1=rs.getString(2);
                		    double perc1=rs.getDouble(3);
                       		    System.out.println(no1+"\t"+name1+"\t"+perc1);
                      		  }
                          	 rs.close();
                          	 st.close();
                          	 break;
                   	  case 3:System.out.println("Enter Student roll no For Updating Record...");
                           	int no2=Integer.parseInt(br.readLine());
                           	System.out.println("Enter New Roll No");
                           	int no3=Integer.parseInt(br.readLine());
                           	System.out.println("Enter New Student Name");
                           	String name3=br.readLine();
                           	System.out.println("Enter New Student percentage");
                           	double perc3=Double.parseDouble(br.readLine());
                           	pst1=con.prepareStatement("update student set roll='"+no3+"',name='"+name3+"',perc='"+perc3+"' where roll='"+no2+"'");
                           	pst1.executeUpdate();
                           	pst1.close();
                           	System.out.println("Record Successfully Updated...");
                           	break;
                   	 case 4:System.out.println("Enter Student roll no For Deleting Record...");
                           	int no4=Integer.parseInt(br.readLine());
                           	pst2=con.prepareStatement("delete from student where roll='"+no4+"'");
                           	pst2.executeUpdate();
                           	pst2.close();
                           	System.out.println("Record Deleted Successfully...");
                           	break;
                   	 case 5:System.out.println("Enter Student Name For Searching Record...");
                           	String name4=br.readLine();                  
                           	st1=con.createStatement();
                          	rs1=st1.executeQuery("select * from student where name='"+name4+"'");
                          	System.out.println("Roll No\tStudent Name\tPercentage");
                          	while(rs1.next())
                          	{
                          	  int no1=rs1.getInt(1);
                          	  String name1=rs1.getString(2);
                          	  double perc1=rs1.getDouble(3);
                          	  System.out.println(no1+"\t"+name1+"\t"+perc1);
                          	  flag=1;
                          	}
                           	if(flag==1)
                          		System.out.println("Record Found...");
                           	else
                          		System.out.println("Record Not Found...");
	                        rs1.close();
        	                st1.close();
                	        break;
                   	 case 6:System.exit(0);
             	    }
              }while(ch<=6);             
              con.close();
	      }
	      catch(Exception e1)
	      {
	            System.out.println("Error "+e1);
	      }
	}
}
