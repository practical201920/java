import Series.Prime;
import Series.Square;
import java.io.*;

class Slip7_1
{
        public static void main(String a[]) throws IOException
        {
                BufferedReader br =new BufferedReader(new InputStreamReader(System.in));

                System.out.println("Enter no :");
                int no = Integer.parseInt(br.readLine());
                Prime p = new Prime();
                System.out.println("Prime no upto given nos are : ");
                p.prime_range(no);

                Square s = new Square();
                System.out.println("Sqaure upto given nos are : ");
                s.square_range(no);

        }
}