import java.awt.*;
import java.awt.event.*;

public class Slip6_1 extends Frame implements ActionListener
{
        Label labelD, labelB, labelO,labelH;
        TextField  txtNo, txtB, txtO,txtH;
        Button  cal ,clear;
        Panel p;
       
        public Slip6_1()
        {
                labelD= new Label("Decimal No:");
                labelB = new Label("Binary No : ");
                labelO = new Label("Octal No :");
                labelH = new Label("Hexadecimal No :");

                txtNo = new TextField(10);
                txtB = new TextField(10);
                txtO = new TextField(10);
                txtH = new TextField(10);

                cal = new Button("Calculate");
                clear = new Button("Clear");
               
                p = new Panel();
                p.setLayout(new GridLayout(5,2));
                p.add(labelD);
                p.add(txtNo);
                p.add(labelB);
                p.add(txtB);
                p.add(labelO);
                p.add(txtO);
                p.add(labelH);
                p.add(txtH);
                p.add(cal);
                p.add(clear);
                               
	        setLayout(new FlowLayout());
	        add(p);
	        setTitle("Binary Calculator");
	        setSize(300,300);
	        setVisible(true);
	       
	        cal.addActionListener(this);
                clear.addActionListener(this);
	}


	public void actionPerformed(ActionEvent ae)
	{
                Button btn = (Button)ae.getSource();
                if(btn == cal)
                {
                        int n = Integer.parseInt(txtNo.getText());
                        txtB.setText(Integer.toBinaryString(n));
                        txtO.setText(Integer.toOctalString(n));
                        txtH.setText(Integer.toHexString(n));
                }
               
                if(btn == clear)
                {
                        txtNo.setText("");
                        txtB.setText("");
                        txtO.setText("");
                        txtH.setText("");
                }
	}

	public static void main(String args[])
	{
	        new Slip6_1();
	}
}
