import java.util.*;
import java.io.*;
import java.lang.*;
class mynumber
 {
   private int val;
   mynumber()
     {
      val=0;
     }
   mynumber(int v)
     {
       this.val=v;
     }
   void isnegative()
     {
      if(val<0)
       System.out.println("The number is negative");
      else
        System.out.println("The number is not negative");
     }
   void ispositive()
     {
      if(val>0)
       System.out.println("The number is positive");
      else
        System.out.println("The number is not positive");
     }

   void iszero()
     {
      if(val==0)
       System.out.println("The number is zero");
      else
        System.out.println("The number is not zero");
     }
    
   void isodd()
     {
      if(val%2!=0)
       System.out.println("The number is odd");
      else
        System.out.println("The number is not odd");
     }
    
  void iseven()
     {
      if(val%2==0)
       System.out.println("The number is even");
      else
        System.out.println("The number is not even");
     }
}
class slip18_1
 { 
  
  
 public static void main(String args[])
   {
    mynumber m1=new mynumber(Integer.parseInt(args[0]));
    m1.isnegative();
    m1.ispositive();
    m1.iszero();
    m1.isodd();
    m1.iseven();
   }
}
   
