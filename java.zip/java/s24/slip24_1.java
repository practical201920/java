import java.io.*;
class Vehicle
{
	public String company;
	public double price;
	public Vehicle(String com,double p)
	{
		company=com;
		price=p;
	}
}
class LightMoterVehicle extends Vehicle
{
	double mileage;
	public LightMoterVehicle(String com,double p,double m)
	{
		super(com,p);
		mileage=m;
	}
	public void display()
	{
		System.out.println(company+"\t"+price+"\t"+mileage);
	}
}
class HeavyMoterVehicle extends Vehicle
{
	double capacity;
	public HeavyMoterVehicle(String com,double p,double c)
	{
		super(com,p);
		capacity=c;
	}
	public void display()
	{
		System.out.println(company+"\t"+price+"\t"+capacity);
	}
}
class e18
{
	public static void main(String a[])throws IOException
	{
		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the total vehicle");
		int n=Integer.parseInt(bf.readLine());
		System.out.println("Enter the details of "+n+" Vehicle");
		LightMoterVehicle l[]=new LightMoterVehicle[n];
		HeavyMoterVehicle h[]=new HeavyMoterVehicle[n];
		int lv=0,hv=0,ch;
		for(int i=0;i<n;i++)
		{
			System.out.println("Press 1 for Light Moter Vehicle \nPress 2 for Heavy Moter Vehicle");
			ch=Integer.parseInt(bf.readLine());
			if(ch==1)
			{
				System.out.println("Enter Vehicle company, price, mileage");
				l[lv]=new LightMoterVehicle(bf.readLine(),Double.parseDouble(bf.readLine()),Double.parseDouble(bf.readLine()));
				lv++;
			}
			else
			{
				System.out.println("Enter Vehicle Company, price, Capacity");
				h[hv]=new HeavyMoterVehicle(bf.readLine(),Double.parseDouble(bf.readLine()),Double.parseDouble(bf.readLine()));
				hv++;
			}
		}
		System.out.println("------Light Moter Vehicle Details------");
		System.out.println("Company\tPrice\tMileage");
		for(int i=0;i<lv;i++)
			l[i].display();
		System.out.println("------Heavy Moter Vehicle Details------");
		System.out.println("Company\tPrice\tCapacity");
		for(int i=0;i<hv;i++)
			h[i].display();
	}
}
