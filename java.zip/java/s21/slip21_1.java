import java.io.*;
class Student
{
	int roll;
	String name;
	double perc;
	static int assign;
	public void accept(String name,double perc)
	{
		roll=++assign;
		this.name=name;
		this.perc=perc;
	}
	public void sortStudent(Student s[],int n)
	{
		double p;
		int r;
		String nme;
		for(int i=1;i<n;i++)
		{
			p=s[i].perc;
			r=s[i].roll;
			nme=s[i].name;
			for(int j=i-1;j>=0;j--)
			{
				if(s[j].perc>p)
				{
					s[j+1].roll=s[j].roll;
					s[j+1].perc=s[j].perc;
					s[j+1].name=s[j].name;
					s[j].perc=p;
					s[j].roll=r;
					s[j].name=nme;
				}
			}
		}
	}
	public String display()
	{
		return "[" +roll+ "," +name+ "," +perc+ "]";
	}
}
class slip21_1
{
	public static void main(String[] args) throws IOException
	{
		//String name;
		//double perc;
		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter total student");
		int n=Integer.parseInt(bf.readLine());
		Student[] s=new Student[n];//Here the array index is not perdefined!!!!!!!!!.
		for(int i=0;i<n;i++)
		{
			s[i]=new Student();
		}
		System.out.println("Enter details of " +n+ " student");
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter name and percenteage ");
			s[i].accept(bf.readLine(),Double.parseDouble(bf.readLine()));	//This is short route
		}
		s[0].sortStudent(s,n);
		System.out.println("Details of student");
		for(int i=0;i<n;i++)
		{
			System.out.println(s[i].display());
		}
	}
}
