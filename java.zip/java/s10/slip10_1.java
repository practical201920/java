import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class slip10_1
{
	public static void main(String args[])
	{
		CalculatorFrame frame=new CalculatorFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
 class CalculatorFrame extends JFrame
{
	public CalculatorFrame()
	{
		setTitle("Calculator");
		CalculatorPanel panel=new CalculatorPanel();
		add(panel);
		pack();		//this is used for fit the button
	}
}
class CalculatorPanel extends JPanel
{
	private JButton display;
	private JPanel panel;
	private double result;
	private String lastCommand;
	private boolean start;
	public CalculatorPanel()
	{
		setLayout(new BorderLayout());
		result=0;
		lastCommand="=";
		start=true;

		display=new JButton("0");
		display.setEnabled(false);
		add(display,BorderLayout.NORTH);
		ActionListener insert=new InsertAction();
		ActionListener command=new CommandAction();
		
		panel=new JPanel();
		panel.setLayout(new GridLayout(4,4));
		
		addbutton("1",insert);
		addbutton("2",insert);
		addbutton("3",insert);
		addbutton("+",command);
		addbutton("4",insert);
		addbutton("5",insert);
		addbutton("6",insert);
		addbutton("-",command);
		addbutton("7",insert);
		addbutton("8",insert);
		addbutton("9",insert);
		addbutton("*",command);
		addbutton("0",insert);
		addbutton(".",insert);
		addbutton("=",command);
		addbutton("/",command);
		
		add(panel,BorderLayout.CENTER);
	}
	private void addbutton(String label,ActionListener listener)
	{
		JButton button=new JButton(label);
		button.addActionListener(listener);
		panel.add(button);
	}
	private class InsertAction implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			String input=e.getActionCommand();
			if(start)
			{
				display.setText("");
				start=false;
			}
			display.setText(display.getText()+input);
		}
	}
	private class CommandAction implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			String command=e.getActionCommand();
			if(start)
			{
				if(command.equals("-"))
				{
					display.setText(command);
					start=false;
				}
				else
					lastCommand=command;
			}
			else
			{
				calculate(Double.parseDouble(display.getText()));
				lastCommand=command;
				start=true;
			}
		}
	}
	public void calculate(double x)
	{
		try
		{
		if(lastCommand.equals("+"))
			result+=x;
		else if(lastCommand.equals("-"))
			result-=x;
		else if(lastCommand.equals("*"))
			result*=x;
		else if(lastCommand.equals("/"))
			result/=x;
		else if(lastCommand.equals("="))
			result=x;
		display.setText(""+result);
		}
		catch(ArithmeticException e)
		{
			System.out.println("Error:"+e);
		}
		catch(NumberFormatException e)
		{
			System.out.println("Error:"+e);
		}
		catch(Exception e)
		{
			System.out.println("Error:"+e);
		}
	}
}
