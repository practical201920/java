import java.util.*;
import java.io.*;
class slip19_2
{
	public static void main(String args[])throws IOException
	{
		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
		TreeSet ts=new TreeSet();
		System.out.println("Enter the total no of integer's:");
		int n=Integer.parseInt(bf.readLine());
		System.out.println("Enter the "+n+" Integer");
		for(int i=0;i<n;i++)
		{
			ts.add(Integer.parseInt(bf.readLine()));
		}
		System.out.println("The TreeSet in Sorted Order is:");
		System.out.println(ts);
		System.out.println("Enter the Integer You want to search:");
		n=Integer.parseInt(bf.readLine());
		if(ts.contains(n))
			System.out.println("Integer is Present in TreeSet");
		else
			System.out.println("Integer is not present is TreeSet");
	}
}
