import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class slip19_1 extends Applet implements MouseListener,MouseMotionListener,KeyListener
{
	String msg="",key="";

	public void init()
	{
		addMouseListener(this);
		addMouseMotionListener(this);
		addKeyListener(this);
	}
	public void mouseClicked(MouseEvent me)
	{
		msg="Mouse Clik";
		key="";
		key+=me.getButton();
		msg+=" Button:"+key;
		repaint();
	}
	public void mouseMoved(MouseEvent me)
	{
		msg="Mouse Move";
		repaint();
	}
	public void mouseDragged(MouseEvent me)
	{
		msg="Mouse Dragged";
		repaint();
	}
	public void mousePressed(MouseEvent me)
	{
		msg="Mouse Pressed";
		key="";
		key+=me.getButton();
		msg+=" Button:"+key;
		repaint();
	}
	public void mouseExited(MouseEvent me)
	{
		msg="Mouse Exited";
		repaint();
	}
	public void mouseEntered(MouseEvent me)
	{
		msg="Mouse Entered";
		repaint();
	}
	public void mouseReleased(MouseEvent me)
	{
		msg="Mouse Release";
		repaint();
	}
	public void keyPressed(KeyEvent ke)
	{
		msg="Key Pressed";
		key="";
		key+=ke.getKeyChar();		
		msg+=" Button:"+key;
		repaint();
	}
	public void keyReleased(KeyEvent ke)
	{
		msg="Key Released";
		key="";
		key+=ke.getKeyChar();		
		msg+=" Button:"+key;
		repaint();
	}
	public void keyTyped(KeyEvent ke)
	{	
		repaint();
	}
	public void paint(Graphics g)
	{
		g.drawString(msg,450,450);
	}
}

