import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
//import java.util.*;

class myframe extends JFrame  implements  ActionListener
  {
    JPanel p1;
    JButton b1,b2,b3,b4,b5,b6,b7,b8;
    List l1,l2;  
    DefaultListModel lm1,lm2;
     
   myframe()
     {
       b1=new JButton("<<");
       b2=new JButton("<");
       b3=new JButton(">>");
       b4=new JButton(">");
       b5=new JButton("Add");
       b6=new JButton("Remove");
       b7=new JButton("Add");
       b8=new JButton("Remove");
       l1=new List();
       l2=new List();
       l1.add("    List1");
       l2.add("    List2");
     
       add(l1);
       add(b1);
       add(l2);
       add(b2); 
       add(b3);
       add(b4);
       add(b5);
       add(b6);
       add(b7);
       add(b8);
        
       l1.addActionListener(this);
       l2.addActionListener(this); 
       b1.addActionListener(this);
       b2.addActionListener(this);
       b3.addActionListener(this);
       b4.addActionListener(this);
       b5.addActionListener(this);
       b6.addActionListener(this);
       b7.addActionListener(this);
       b8.addActionListener(this);
       
       setLayout(new BorderLayout());
      
       l1.setBounds(50,70,70,130);
       b1.setBounds(140,60,50,30);
       l2.setBounds(210,70,70,130);
       b2.setBounds(140,100,50,30);
       b3.setBounds(140,140,50,30);
       b4.setBounds(140,180,50,30);
       b5.setBounds(10,220,60,20);
       b6.setBounds(80,220,80,20);
       b7.setBounds(170,220,60,20);
       b8.setBounds(240,220,80,20); 
       
       setSize(500,500);
       setVisible(true);
    }
   public void actionPerformed(ActionEvent a)
    {
       
       if(a.getSource()==b1)
    	 { 
    	//  String name=l2.getItem();
    	//   l1.add(name);
    	 }
       if(a.getSource()==b2)
    	 { 
    	   String name=JOptionPane.showInputDialog(null);
    	   l1.remove(name);
    	 } 
       if(a.getSource()==b3)
    	 { 
    	   String name=JOptionPane.showInputDialog(null);
    	   l1.add(name);
    	 }
       if(a.getSource()==b4)
    	 { 
    	   String name=JOptionPane.showInputDialog(null);
    	   l1.remove(name);
    	 }  
   
       if(a.getSource()==b5)
    	 { 
    	   String name=JOptionPane.showInputDialog(null);
    	   l1.add(name);
    	 }
       if(a.getSource()==b6)
    	 { 
    	   String name=JOptionPane.showInputDialog(null);
    	   l1.remove(name);
    	 } 
       if(a.getSource()==b7)
    	 { 
    	   String name=JOptionPane.showInputDialog(null);
    	   l2.add(name);
    	 }
       if(a.getSource()==b8)
    	 { 
    	   String name=JOptionPane.showInputDialog(null);
    	   l2.remove(name);
    	 }  
    } 
}
class list
 {
   public static void main(String args[])
     {
       new myframe();
     }
 }
