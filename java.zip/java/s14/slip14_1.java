import java.io.*;
import java.util.*;
class e40
{
	public static void main(String args[])throws IOException
	{
		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the total student");
		int n=Integer.parseInt(bf.readLine());
		File f=new File("Student.dat");
		RandomAccessFile fp1=new RandomAccessFile(f,"rw");
		System.out.println("Enter the Details of "+n+" Students");
		System.out.println("<Roll No>  <Name>  <Percentage>");
		String s;
		for(int i=0;i<n;i++)
		{
			s=bf.readLine()+"\n";
			fp1.writeBytes(s);
		}
		fp1.close();
		RandomAccessFile fp2=new RandomAccessFile(f,"rw");
		System.out.println("Enter the roll number");
		int roll=Integer.parseInt(bf.readLine());
		boolean flag=false;
		for(int i=0;i<n;i++)
		{
			s=fp2.readLine();
			StringTokenizer t=new StringTokenizer(s," ");
			String sr=new String(t.nextToken());
			if(roll==(Integer.parseInt(sr)))
			{
				flag=true;
				System.out.println(s);
			}
		}
		fp2.close();
		if(!flag)
			System.out.println("Record Not Found");
	}
}
