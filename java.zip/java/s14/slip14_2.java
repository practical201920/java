import java.util.*;
class slip14_2
{
	public static void main(String args[])
	{
		LinkedList ll=new LinkedList();
		ll.add("red");
		ll.add("blue");
		ll.add("yellow");
		ll.add("orange");
		System.out.println("Display the contents of the List using an Iterator:");
		Iterator it=ll.iterator();
		while(it.hasNext())
		{
			String obj=(String)it.next();
			System.out.println(obj);
		}
		System.out.println("Display the contents of the List in reverse order using a ListIterator:");
		ListIterator litr=ll.listIterator();
		while(litr.hasNext())
			litr.next();
		while(litr.hasPrevious())
			System.out.println(litr.previous());
		List l=new ArrayList();
		l.add("pink");
		l.add("green");
		ll.addAll(2,l);
		System.out.println("Creating another list containing pink and green. Insert the elements of this list between blue and yellow");
		System.out.println(ll);
	}
}
