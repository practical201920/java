package TY;
public class TYMarks
{
	public int theory,practical;
	public void accept(int t,int p)
	{
		theory=t;
		practical=p;
	}	
}
