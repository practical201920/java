package SY;
public class SYMarks
{
	public int Computertotal,Mathstotal,Electronicstotal;
	public void accept(int c,int m,int e)
	{
		Computertotal=c;
		Mathstotal=m;
		Electronicstotal=e;
	}
}
