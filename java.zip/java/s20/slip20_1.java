import SY.*;
import TY.*;
import java.io.*;
class e9
{
	int roll;
	String name;
	SYMarks sy=new SYMarks();
	TYMarks ty=new TYMarks();
	public void accept(int r,String nme,int l,int m,int n,int p,int q)
	{
		roll=r;
		name=nme;
		sy.accept(l,m,n);
		ty.accept(p,q);
	}
	public static void main(String args[]) throws IOException
	{
		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the total student");
		int n=Integer.parseInt(bf.readLine());
		e9[] s=new e9[n];
		for(int i=0;i<n;i++)
			s[i]=new e9();
		System.out.println("Enter the details of "+n+" student");
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter the roll no, name, SY total marks of computer, maths and electronics, TY total marks of theory and practical");
			s[i].accept(Integer.parseInt(bf.readLine()),bf.readLine(),Integer.parseInt(bf.readLine()),Integer.parseInt(bf.readLine()),Integer.parseInt(bf.readLine()),Integer.parseInt(bf.readLine()),Integer.parseInt(bf.readLine()));
		}
		System.out.println("--------------------Student Result Information--------------------");
		System.out.println("RNo.      Name   SY Comp  SY Math  SY Elect.  TY Theory  TY Prctical  Computer Marks Grade");
		for(int i=0;i<n;i++)
		{
			double comp=s[i].sy.Computertotal+s[i].ty.theory+s[i].ty.practical;
			comp/=5;
			if(comp>=70)
				System.out.println(s[i].roll+"\t"+s[i].name+"\t  "+s[i].sy.Computertotal+"\t  "+s[i].sy.Mathstotal+"\t   "+s[i].sy.Electronicstotal+"\t\t"+s[i].ty.theory+"\t   "+s[i].ty.practical+"\t        "+comp+"\t       A");
			else if(comp>=60&&comp<70)
				System.out.println(s[i].roll+"\t"+s[i].name+"\t  "+s[i].sy.Computertotal+"\t  "+s[i].sy.Mathstotal+"\t   "+s[i].sy.Electronicstotal+"\t\t"+s[i].ty.theory+"\t   "+s[i].ty.practical+"\t        "+comp+"\t       B");
			else if(comp>=50&&comp<60)
				System.out.println(s[i].roll+"\t"+s[i].name+"\t  "+s[i].sy.Computertotal+"\t  "+s[i].sy.Mathstotal+"\t   "+s[i].sy.Electronicstotal+"\t\t"+s[i].ty.theory+"\t   "+s[i].ty.practical+"\t        "+comp+"\t       C");
			else if(comp>=40&&comp<50)
				System.out.println(s[i].roll+"\t"+s[i].name+"\t  "+s[i].sy.Computertotal+"\t  "+s[i].sy.Mathstotal+"\t   "+s[i].sy.Electronicstotal+"\t\t"+s[i].ty.theory+"\t   "+s[i].ty.practical+"\t        "+comp+"\t       Pass");
			else
				System.out.println(s[i].roll+"\t"+s[i].name+"\t  "+s[i].sy.Computertotal+"\t  "+s[i].sy.Mathstotal+"\t   "+s[i].sy.Electronicstotal+"\t\t"+s[i].ty.theory+"\t   "+s[i].ty.practical+"\t     "+comp+"\t     Fail");
		}
	}
}
