import java.io.*;
interface CreditCardInterface
{
	double viewCreditAmount();
	int viewPin();
	void changePin(int n);
	void useCard(double amt);
	void payBalance(double amt);
}
abstract class Customer implements CreditCardInterface
{
	public String name;
	public int cardNumber;
	public int pin;
	public double creditAmount;
        public Customer(String nme,int no)
	{
		name=nme;
		cardNumber=no;
		pin=12345;
		creditAmount=0;
	}
	public double viewCreditAmount()
	{
		return creditAmount;
	}
	public int viewPin()
	{
		return pin;
	}
	public void changePin(int n)
	{
		pin=n;
	}
	public void payBalance(double amt)
        {
                creditAmount+=amt;
        }
	public abstract void useCard(double amt);
}
class RegularCardHolder extends Customer
{
	int maxCreditLimit;
	public RegularCardHolder(String nme,int no)
	{
		super(nme,no);
		maxCreditLimit=10000;
	}
	public void useCard(double amt)
	{
		if(amt<=maxCreditLimit&&creditAmount-amt>500)
			creditAmount-=amt;
		else
			System.out.println("Please Try again...!!!");
	}
}
class GoldenCardHolder extends Customer
{
	String specicalPrivileges;
	public GoldenCardHolder(String nme,int no,String pri)
	{
		super(nme,no);
		specicalPrivileges=pri;
	}
	public void useCard(double amt)
	{
		if(creditAmount-amt>0)
			creditAmount-=amt;
		else
			System.out.println("Please Try again");
	}
}
class slip23_1
{
	public static void main(String a[])throws IOException
	{
		BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the total regular card Holder");
		int n1=Integer.parseInt(bf.readLine());
		System.out.println("Enter the details of "+n1+" Regular card Holder");
		RegularCardHolder[] r=new RegularCardHolder[n1];
		for(int i=0;i<n1;i++)
		{
			System.out.println("Enter the name of customer and card number");
			r[i]=new RegularCardHolder(bf.readLine(),Integer.parseInt(bf.readLine()));
		}
		System.out.println("Enter the total Golden card Holder");
                int n2=Integer.parseInt(bf.readLine());
		System.out.println("Enter the Details of "+n2+" Golden card holder");
		GoldenCardHolder[] g=new GoldenCardHolder[n2];
		for(int i=0;i<n2;i++)
		{
			System.out.println("Enter the name of customer, card number and Privileges for customer");
			g[i]=new GoldenCardHolder(bf.readLine(),Integer.parseInt(bf.readLine()),bf.readLine());
		}
		int ch,ch1,t1,flag;
		do
		{
			System.out.println("------Credit Card Menu------");
			System.out.println("1:Regular Card Holder");
			System.out.println("2:Golden Card Holder");
			System.out.println("3:Quit");
			System.out.println("----------------------------");
			System.out.println("Enter the choice");
			ch=Integer.parseInt(bf.readLine());
			switch(ch)
			{
				case 1:System.out.println("Enter the Card Number");
					t1=Integer.parseInt(bf.readLine());
					flag=0;
					for(int i=0;i<n1;i++)
					{
						if(r[i].cardNumber==t1)
						{
							flag=1;
							System.out.println("Enter the pin");
							if(Integer.parseInt(bf.readLine())==r[i].viewPin())
							{
							System.out.println("------Menu of Action------");
							System.out.println("1:Use Card");
							System.out.println("2:Pay Balance");
							System.out.println("3:Change Pin");
							System.out.println("--------------------------");
							System.out.println("Enter the choice");
							ch1=Integer.parseInt(bf.readLine());
							switch(ch1)
							{
								case 1:System.out.println("Enter the amount");
									r[i].useCard(Double.parseDouble(bf.readLine()));
									break;
								case 2:System.out.println("Enter the Balanc");
									r[i].payBalance(Double.parseDouble(bf.readLine()));
									break;
								case 3:System.out.println("Enter the new Pin");
									r[i].changePin(Integer.parseInt(bf.readLine()));
									break;
								default:System.out.println("Invalid choice");
									break;
							}
							}
							else
								System.out.println("Enter the Valid pin");
						}
					}
					if(flag==0)
						System.out.println("Enter the valid card number");
					break;
				case 2:System.out.println("Enter the Card Number");
                                        t1=Integer.parseInt(bf.readLine());
					flag=0;
                                        for(int i=0;i<n2;i++)
                                        {
                                                if(g[i].cardNumber==t1)
                                                {
							flag=1;
                                                        System.out.println("Enter the pin");
                                                        if(Integer.parseInt(bf.readLine())==g[i].viewPin())
                                                        {
                                                        System.out.println("------Menu of Action------");
                                                        System.out.println("1:Use Card");
                                                        System.out.println("2:Pay Balance");
                                                        System.out.println("3:Change Pin");
                                                        System.out.println("--------------------------");
                                                        System.out.println("Enter the choice");
                                                        ch1=Integer.parseInt(bf.readLine());
                                                        switch(ch1)
                                                        {
                                                                case 1:System.out.println("Enter the amount");
                                                                        g[i].useCard(Double.parseDouble(bf.readLine()));
                                                                        break;
                                                                case 2:System.out.println("Enter the Balanc");
                                                                        g[i].payBalance(Double.parseDouble(bf.readLine()));
                                                                        break;
                                                                case 3:System.out.println("Enter the new Pin");
                                                                        g[i].changePin(Integer.parseInt(bf.readLine()));
                                                                        break;
                                                                default:System.out.println("Invalid choice");
                                                                        break;
                                                        }
                                                        }
                                                        else
                                                                System.out.println("Enter the Valid pin");
                                                }
					}
					if(flag==0)
						System.out.println("Enter the valid card number");  
					break;
				case 3:break;
				default:System.out.println("Enter the valid choice...!!!");
					break;
			}
		}while(ch!=3);
	}
}
