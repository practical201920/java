import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class slip8_2 extends HttpServlet
{
	static Integer count;
	public void doGet(HttpServletRequest req, HttpServletResponse res)throws IOException,ServletException
	{
		doPost(req,res);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse res)throws IOException,ServletException
	{
		res.setContentType("text/html");
		PrintWriter out=res.getWriter();
		Cookie c=new Cookie("Count",count+"");
		res.addCookie(c);
		String strCount=c.getValue();
		if(count==null)
		{
			count=new Integer(1);
			out.println("Welcome...");
		}
		else
		{
			count = Integer.parseInt(strCount);
			out.println("<html><body><br> Number of times previous visited: "+count+"<br></body></html>");
			count=new Integer((count.intValue())+1);
		}
	}
}
