import java.awt.*;
import java.awt.event.*;
import java.awt.Font;
import java.awt.font.TextAttribute;
import javax.swing.*;
import java.util.*;
class slip8_1
{
	JLabel l1,l2,l3,l4,l5,l6;
	JComboBox cb1,cb2;
	JTextField t1;
	JCheckBox cx1,cx2,cx3;
	JPanel pnl_east,pnl_west,pnl_south,panel;
	JFrame fr;
	String title;
	ActionListener listener;
	public static void main(String args[])
	{
		slip8_1 s=new slip8_1();
	}
	public slip8_1()
	{
		fr=new JFrame("My Frame");
		fr.setLayout(null);
		panel=new JPanel();
		panel.setLayout(new BorderLayout());
		l1=new JLabel("Font");
		l2=new JLabel("Style");
		l6=new JLabel("Size");
		cb1=new JComboBox(new String[] {"Serif","SansSerif","Monospaced","Dialog","DialogInput"});
		cb2=new JComboBox(new String[] {"8","10","12","14","16","18","20"});
		cx1=new JCheckBox("Bold");
		cx2=new JCheckBox("Italic");
		cx3=new JCheckBox("Underline");
		t1=new JTextField("This is My Power",15);
		t1.setFont(new java.awt.Font("Serif",Font.PLAIN,22));
		t1.setHorizontalAlignment(JTextField.CENTER);
		pnl_east=new JPanel();
		pnl_east.setLayout(new GridLayout(4,1));
		pnl_east.add(l2);
		pnl_east.add(cx1);
		pnl_east.add(cx2);
		pnl_east.add(cx3);
		pnl_west=new JPanel();
		pnl_west.setLayout(new GridLayout(4,1));
		pnl_west.add(l1);
		pnl_west.add(cb1);
		pnl_west.add(l6);
		pnl_west.add(cb2);
		pnl_south=new JPanel();
		pnl_south.add(t1);		
		panel.add(pnl_east,BorderLayout.EAST);
		panel.add(pnl_south,BorderLayout.SOUTH);
		panel.add(pnl_west,BorderLayout.WEST);
		listener=new FontAction();
		cb1.addActionListener(listener);
		cb2.addActionListener(listener);
		cx1.addActionListener(listener);
		cx2.addActionListener(listener);
		cx3.addActionListener(listener);
		t1.addActionListener(listener);
		fr.add(panel);
		panel.setBounds(10,10,240,150);
		fr.setSize(260,200);
		fr.setVisible(true);
		fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		
	}
	public class FontAction implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			String fontface=(String)cb1.getSelectedItem();
			int fontstyle=(cx1.isSelected()? Font.BOLD:0)
					+(cx2.isSelected()? Font.ITALIC:0);
			int fontsize=Integer.parseInt((String) cb2.getSelectedItem());
			Font font=new Font(fontface,fontstyle,fontsize);
			if(cx3.isSelected())
			{
				Map attribute=font.getAttributes();
				attribute.put(TextAttribute.UNDERLINE,TextAttribute.UNDERLINE_ON);
				t1.setFont(font.deriveFont(attribute));
			}
			else
				t1.setFont(font);
			

		}
	}
}
